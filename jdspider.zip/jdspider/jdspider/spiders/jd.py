# -*- coding: utf-8 -*-
import scrapy
from scrapy.selector import Selector

class JdSpider(scrapy.Spider):
    name = "jd"
    allowed_domains = ["jd.com"]
    start_urls = (
        'http://www.jd.com/',
    )

    def parse(self, response):
        # print response.body
        selector=Selector(response)
        title=selector.xpath('//title/text()').extract()[0]  #xpath获取JD首页title
        print title
